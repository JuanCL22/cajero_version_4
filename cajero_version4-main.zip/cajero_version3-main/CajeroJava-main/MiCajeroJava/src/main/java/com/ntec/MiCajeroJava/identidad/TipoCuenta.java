package com.ntec.MiCajeroJava.identidad;

public enum TipoCuenta {
    AHORROS, CORRIENTE
}
