package com.ntec.MiCajeroJava.identidad;

public enum TipoMovimiento {
    CONSULTA, RETIRO, TRANSFERENCIA, CONSIGNACION,
}
